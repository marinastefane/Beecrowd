#include <iostream>

int main()
{
    int numero;
    std::cin >> numero;
    std::cout << numero * 4 << std::endl;
    return 0;
}