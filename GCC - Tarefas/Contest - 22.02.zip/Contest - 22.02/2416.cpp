#include <bits/stdc++.h>
using namespace std;

int main()
{
    int c, n;

    std::cin >> c;
    std::cin >> n;

    // % -> resto da divisao de c por n
    std::cout << c % n << std::endl;

    return 0;
}